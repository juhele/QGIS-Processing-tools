# -*- coding: utf-8 -*-
"""
PAA Point Loader
Loads current public dose-rate data from the Polish PAA network
(PMS stations + IMGW automatic stations) via WFS.
Creates a point layer in EPSG:4326 and optionally applies one of two styles.
"""

from qgis.PyQt.QtCore import (
    QCoreApplication, QVariant, QUrl, QMetaType, QTemporaryFile
)
from qgis.PyQt.QtNetwork import QNetworkRequest
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingException,
    QgsFeature,
    QgsFields,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsFeatureSink,
    QgsBlockingNetworkRequest,
    QgsProcessingLayerPostProcessorInterface,
    QgsVectorLayer,
)
import json
from datetime import datetime, timedelta, timezone
import os


class StylePostProcessor(QgsProcessingLayerPostProcessorInterface):
    """Applies a QML style after the layer has been loaded into the project."""

    instance = None
    style_path = None          # preferred path to real .qml file
    style_content = None       # fallback embedded content (optional)

    def postProcessLayer(self, layer, context, feedback):
        if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
            return

        # 1. Prefer the real QML file on disk
        if self.style_path and os.path.isfile(self.style_path):
            msg, ok = layer.loadNamedStyle(self.style_path)
            if ok:
                layer.triggerRepaint()
                feedback.pushInfo(f'Style applied: {os.path.basename(self.style_path)}')
                return
            else:
                feedback.pushWarning(f'Could not load style from file: {msg}')

        # 2. Fallback – write embedded content to a temporary file
        if self.style_content:
            tmp = QTemporaryFile()
            tmp.setAutoRemove(True)          # Qt will clean up later
            if tmp.open():
                tmp.write(self.style_content.encode('utf-8'))
                tmp.flush()
                path = tmp.fileName()
                msg, ok = layer.loadNamedStyle(path)
                if ok:
                    layer.triggerRepaint()
                    feedback.pushInfo('Style applied from embedded content')
                else:
                    feedback.pushWarning(f'Could not apply embedded style: {msg}')
            else:
                feedback.pushWarning('Could not create temporary style file')
        else:
            feedback.pushWarning(
                'No style file found next to the script and no embedded style available.'
            )

    @staticmethod
    def create(style_path: str = None, style_content: str = None):
        StylePostProcessor.instance = StylePostProcessor()
        StylePostProcessor.instance.style_path = style_path
        StylePostProcessor.instance.style_content = style_content
        return StylePostProcessor.instance


class PAAPointLoaderAlgorithm(QgsProcessingAlgorithm):

    STATION_TYPE = 'STATION_TYPE'
    DAYS_BACK = 'DAYS_BACK'
    TIMEOUT = 'TIMEOUT'
    STYLE = 'STYLE'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return PAAPointLoaderAlgorithm()

    def name(self):
        return 'paa_point_loader'

    def displayName(self):
        return self.tr('PAA Point Loader')

    def group(self):
        return self.tr('Radioactivity')

    def groupId(self):
        return 'radioactivity'

    def shortHelpString(self):
        return self.tr(
            "Loads current public ambient dose-rate measurements from the "
            "Polish National Atomic Energy Agency (PAA) Permanent Monitoring "
            "Stations (PMS) and from the automatic IMGW stations.\n\n"
            "Data are retrieved via WFS as GeoJSON and converted to a point "
            "layer (EPSG:4326).\n\n"
            "Place the two QML style files next to this script:\n"
            "• style_1_CzechRad_colors.qml\n"
            "• style_2_PAA_default_colors.qml"
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.STATION_TYPE,
            self.tr('Station type'),
            options=['Both (PMS + IMGW)', 'PMS only', 'IMGW only'],
            defaultValue=0
        ))

        self.addParameter(QgsProcessingParameterNumber(
            self.DAYS_BACK,
            self.tr('Days back for date_from (date_to = today)'),
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=30,
            minValue=1,
            maxValue=365
        ))

        self.addParameter(QgsProcessingParameterNumber(
            self.TIMEOUT,
            self.tr('Network timeout (seconds)'),
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=120,
            minValue=30,
            maxValue=300
        ))

        self.addParameter(QgsProcessingParameterEnum(
            self.STYLE,
            self.tr('Style to apply'),
            options=[
                'Style 1 – CzechRad colours (default)',
                'Style 2 – PAA default colours',
                'No style'
            ],
            defaultValue=0
        ))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT,
            self.tr('PAA doserate uSvh'),
            type=QgsProcessing.TypeVectorPoint
        ))

    def _fetch_json(self, url: str, timeout_sec: int, feedback) -> dict:
        request = QNetworkRequest(QUrl(url))
        request.setRawHeader(b'User-Agent', b'QGIS-PAA-Point-Loader/1.3')
        request.setTransferTimeout(timeout_sec * 1000)

        blocking = QgsBlockingNetworkRequest()
        err = blocking.get(request, forceRefresh=True, feedback=feedback)

        if err != QgsBlockingNetworkRequest.NoError:
            raise QgsProcessingException(
                f'Network error: {blocking.errorMessage()}\nURL: {url}\n\n'
                'Possible causes:\n'
                '• Firewall / antivirus / proxy\n'
                '• Server temporarily slow – try a higher timeout value'
            )

        content = blocking.reply().content()
        if not content:
            raise QgsProcessingException('Empty response from server')

        try:
            return json.loads(bytes(content).decode('utf-8'))
        except json.JSONDecodeError as e:
            raise QgsProcessingException(f'Invalid JSON received: {e}')

    def processAlgorithm(self, parameters, context, feedback):
        station_choice = self.parameterAsEnum(parameters, self.STATION_TYPE, context)
        days_back = self.parameterAsInt(parameters, self.DAYS_BACK, context)
        timeout_sec = self.parameterAsInt(parameters, self.TIMEOUT, context)
        style_choice = self.parameterAsEnum(parameters, self.STYLE, context)

        # ---------- dates (UTC) ----------
        now = datetime.now(timezone.utc)
        date_to = now.strftime('%Y-%m-%dT23:59:59.000Z')
        date_from = (now - timedelta(days=days_back)).strftime('%Y-%m-%dT00:00:00.000Z')
        feedback.pushInfo(f'Date range: {date_from} → {date_to}')

        base = 'https://monitoring.paa.gov.pl/geoserver/ows'
        common = (
            f'?service=WFS&version=2.0.0&request=GetFeature'
            f'&outputFormat=application/json'
            f'&viewparams=date_from:{date_from};date_to:{date_to}'
        )

        urls = []
        if station_choice in (0, 1):          # Both or PMS
            urls.append((
                'PMS',
                f'{base}{common}&typeNames=paa:kcad_siec_pms_moc_dawki_mapa'
            ))
        if station_choice in (0, 2):          # Both or IMGW
            urls.append((
                'IMGW',
                f'{base}{common}&typeNames=paa:kcad_siec_imgw_auto_moc_dawki_mapa'
            ))

        # ---------- fields (modern constructor) ----------
        fields = QgsFields()
        fields.append(QgsField('longitude',     QMetaType.Type.Double,  'double', 12, 6))
        fields.append(QgsField('latitude',      QMetaType.Type.Double,  'double', 12, 6))
        fields.append(QgsField('station_type',  QMetaType.Type.QString, 'string', 10))
        fields.append(QgsField('station_name',  QMetaType.Type.QString, 'string', 80))
        fields.append(QgsField('doserate_uSvh', QMetaType.Type.Double,  'double', 10, 4))
        fields.append(QgsField('datetime',      QMetaType.Type.QString, 'string', 25))
        fields.append(QgsField('station_id',    QMetaType.Type.QString, 'string', 50))

        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            fields, QgsWkbTypes.Point,
            QgsCoordinateReferenceSystem('EPSG:4326')
        )
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        total = 0
        for stype, url in urls:
            feedback.pushInfo(f'Fetching {stype} …')
            feedback.pushInfo(url)

            geojson = self._fetch_json(url, timeout_sec, feedback)
            features = geojson.get('features', [])
            feedback.pushInfo(f'  → {len(features)} features')

            for feat in features:
                if feedback.isCanceled():
                    break

                props = feat.get('properties', {})
                coords = feat.get('geometry', {}).get('coordinates', [None, None])
                if coords[0] is None or coords[1] is None:
                    continue

                lon = float(coords[0])
                lat = float(coords[1])

                # dose rate – extract numeric value from "0.052 µSv/h"
                tip_value = props.get('tip_value', '')
                try:
                    doserate = float(tip_value.split()[0].replace(',', '.'))
                except (ValueError, IndexError):
                    doserate = None

                # datetime → ISO / GPX style
                tip_date = props.get('tip_date', '')
                iso_dt = ''
                if tip_date:
                    try:
                        dt = datetime.strptime(tip_date.strip(), '%Y-%m-%d %H:%M')
                        iso_dt = dt.strftime('%Y-%m-%dT%H:%M:%SZ')
                    except ValueError:
                        iso_dt = tip_date

                f = QgsFeature(fields)
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
                f.setAttributes([
                    lon,
                    lat,
                    stype,
                    props.get('tip_name') or props.get('stacja') or '',
                    doserate,
                    iso_dt,
                    props.get('id', '')
                ])
                sink.addFeature(f, QgsFeatureSink.FastInsert)
                total += 1

        feedback.pushInfo(f'Total features written: {total}')

        # ---------- apply style ----------
        if style_choice < 2 and total > 0 and context.willLoadLayerOnCompletion(dest_id):
            script_dir = os.path.dirname(os.path.realpath(__file__))
            qml_name = (
                'style_1_CzechRad_colors.qml'
                if style_choice == 0
                else 'style_2_PAA_default_colors.qml'
            )
            style_path = os.path.join(script_dir, qml_name)

            details = context.layerToLoadOnCompletionDetails(dest_id)
            details.setPostProcessor(
                StylePostProcessor.create(style_path=style_path)
            )

        return {self.OUTPUT: dest_id}      
               
# Created with Grok AI, released under CC0 1.0 Universal License
# Copyright 2026 Jan Helebrant, czechrad@suro.cz, www.suro.cz
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE
